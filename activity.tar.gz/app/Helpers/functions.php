<?php

/**
 * @return bool|mixed
 */
function get_img_source()
{
    if(($img_url = request() ->get('img_url'))) {
        $img_url = urldecode($img_url);
        if(! preg_match('/http:\/\/[^.]*\.qlogo\.cn/',$img_url) && ! preg_match('/myqcloud/',$img_url) ) {
            return false;
        }
        header('Content-type:image/jpeg;charset=utf-8');
        $ch = curl_init($img_url);
        curl_setopt($ch,CURLOPT_HEADER,0);
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
        $response = curl_exec($ch);
        curl_close($ch);
        return $response;
    }
}