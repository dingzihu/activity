<?php

namespace App\Http\Controllers\Api;

use App\Api\Helpers\Api\ApiResponse;
use App\Http\Controllers\Controller;

class ApiController extends Controller
{

    use ApiResponse;

    // 其他通用的Api帮助函数

}