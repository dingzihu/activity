<?php

namespace App\Http\Controllers\Api;

use App\Api\Helpers\Api\Jssdk;

class IndexController extends ApiController
{
    /**
     * 获取微参数信
     * @return mixed
     */
    public function get_wx_params(){
        $jssdk = new JSSDK(env('APPID'), env('APPSECRET'));
        $signPackage = $jssdk->GetSignPackage();
        return  $this ->success($signPackage);
    }

    /**
     * 获取用户信息
     * @return mixed
     */
    public function get_user_info()
    {
        $code = request() ->get('code');
        $appId = env('APPID');
        $appSecret = env('APPSECRET');
        $data = file_get_contents('https://api.weixin.qq.com/sns/oauth2/access_token?appid='.$appId.
            '&secret='.$appSecret.'&code='.$code.'&grant_type=authorization_code');
        $access_token = json_decode($data,true);
        if (isset($access_token['errcode'])){
            return  $this ->failed($access_token['errmsg']);
        }else{
            $data = file_get_contents('https://api.weixin.qq.com/sns/oauth2/refresh_token?appid='.$appId.
                '&grant_type=refresh_token&refresh_token='.$access_token['refresh_token']);
            $data = file_get_contents('https://api.weixin.qq.com/sns/userinfo?access_token='.
                $access_token['access_token'].'&openid='.$access_token['openid'].'&lang=zh_CN');
            $user_data =  json_decode($data,true);
            if (isset($user_data['errcode'])){
                return  $this ->failed($user_data['errmsg']);
            }else{
                return  $this ->success(['nickname' => $user_data['nickname'],'headimgurl' => $user_data['headimgurl']]);
            }
        }
    }
}