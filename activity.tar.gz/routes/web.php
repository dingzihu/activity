<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::group(['namespace' => 'Api','prefix' => 'api'], function(){
    Route::get('get_wx_params', 'IndexController@get_wx_params');
    Route::get('get_user_info', 'IndexController@get_user_info');
    Route::get('download_img', function (){
        echo get_img_source();
    });
});

